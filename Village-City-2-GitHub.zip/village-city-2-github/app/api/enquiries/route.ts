import { env } from 'cloudflare:workers';
import { submit, list, update } from '../../../lib/contact.mjs';
export const dynamic = 'force-dynamic';
export const POST = (request: Request) => submit(request, env.DB);
export const GET = (request: Request) => list(request, env.DB);
export const PATCH = (request: Request) => update(request, env.DB);
