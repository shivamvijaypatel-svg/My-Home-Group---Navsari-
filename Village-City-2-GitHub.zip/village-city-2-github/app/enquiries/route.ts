import html from './inbox.html?raw';
import { isOwner } from '../../lib/contact.mjs';
export const dynamic = 'force-dynamic';
export function GET(request: Request) {
 if (!request.headers.get('oai-authenticated-user-id')) return Response.redirect(new URL('/signin-with-chatgpt?return_to=%2Fenquiries',request.url),302);
 if (!isOwner(request)) return new Response('This inbox is available to the site owner only.',{status:403});
 return new Response(html,{headers:{'Content-Type':'text/html; charset=utf-8','Cache-Control':'no-store'}});
}
