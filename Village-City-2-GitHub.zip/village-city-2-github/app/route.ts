import html from './site.html?raw';
export const dynamic = 'force-dynamic';
export function GET() { return new Response(html, {headers:{'Content-Type':'text/html; charset=utf-8'}}); }
