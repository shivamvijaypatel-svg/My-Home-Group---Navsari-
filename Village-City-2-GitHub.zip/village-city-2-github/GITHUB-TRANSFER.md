# Village City 2 — GitHub transfer

This package contains the latest retrieved source of the Village City 2 website, including its images, map, contact-form API, enquiry inbox, database schema, migrations, and dependency lockfile.

Export prepared: 20 October 2026. Latest saved Site version reported: 20.
Source commit: `8537e30effaa7c4f8b83c8370ad97dbfe169e5e5`.

## Upload to GitHub

1. Extract `Village-City-2-GitHub.zip` on your computer.
2. Create a new empty repository named `village-city-2`. A private repository is a suitable starting choice for this business project.
3. Do not initialize that repository with a README, licence or .gitignore; those files can be managed from this source folder.
4. Open a terminal in the extracted `village-city-2-github` folder and run:

```bash
git init -b main
git add .
git commit -m "Import Village City 2 website"
git remote add origin https://github.com/YOUR-USERNAME/village-city-2.git
git push -u origin main
```

Replace `YOUR-USERNAME` with your GitHub username and authenticate to GitHub when requested. Upload the extracted contents, not just the ZIP. Git includes dotfiles such as `.gitignore` and `.openai/hosting.json`, which may be hidden in Finder.

Official instructions: https://docs.github.com/en/migrations/importing-source-code/using-the-command-line-to-import-source-code/adding-locally-hosted-code-to-github

## Files you will edit

| File or folder | Purpose |
| --- | --- |
| `app/site.html` | Website content, styling and browser interactions |
| `public/assets/` | Project images and location map |
| `app/api/enquiries/route.ts` | Contact-form API routes |
| `lib/contact.mjs` | Validation, database operations and owner access checks |
| `app/enquiries/` | Owner enquiry inbox |
| `db/` and `drizzle/` | Database schema and migrations |
| `package.json` and `pnpm-lock.yaml` | Runtime dependencies and scripts |
| `.openai/hosting.json` | Existing Sites project identity and database binding |

## Development and verification

The project specifies Node.js >=22.13.0 and pnpm 11.25.0. From the project folder, with those tools installed:

```bash
pnpm install --frozen-lockfile
pnpm dev
```

Use the local URL printed by the development server. Run the existing contact logic checks with:

```bash
node tests/contact.test.mjs
```

The application uses Vinext/Vite and a Cloudflare Workers runtime. The current build configuration is retained from the existing Sites project; see `README.md` for its implementation notes. The export was checked for missing referenced image files and archive integrity, and the existing contact tests were run. A fresh dependency install, full production build and deployment on a different host were not performed for this source handoff.

## Hosting and contact-form migration

Copying source to GitHub does not deploy the website or change myhomenavsari.com, its DNS, or the existing live website. GitHub Pages cannot run this project's server API or database-backed enquiry inbox.

To use another host, your developer must provision the database, apply the included migrations, configure the `DB` binding and adapt the build/deployment configuration. Existing enquiry records, runtime secrets and hosting account configuration are not included in this source export.

Owner access currently depends on trusted identity headers supplied by Sites and an owner email check in `lib/contact.mjs`. On a different host, replace this with authenticated server-side identity verification before exposing the inbox or its API. Never treat caller-supplied `oai-authenticated-user-*` headers as trusted authentication. Retain the existing Sites host until migration is configured and verified.

Email and automatic WhatsApp notifications are not configured in the exported application. The website's WhatsApp link opens a chat; it is separate from the stored enquiry form.

## Package contents and ownership

Application source and assets are preserved as retrieved. The original Git history, credentials, local dependencies, build output and runtime database records are excluded. This is a source snapshot, not an account or database backup.

No new open-source licence is granted by this export. Retain the included third-party licence notices.
