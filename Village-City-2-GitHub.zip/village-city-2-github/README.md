# Village City 2

The existing project website is served from `app/site.html`. Images and the schematic map are in `public/assets`.

The contact form posts to `/api/enquiries`. Submissions are validated and saved in the Sites-managed D1 database. The database schema and migrations are in `db/` and `drizzle/`. Retries use a request ID to avoid duplicate enquiries; a honeypot and per-source hourly quota reduce automated submissions.

The site owner can review the most recent 500 submissions, change follow-up status and download CSV at `/enquiries`. Access is checked on every inbox and API request using trusted Sites identity headers. The owner email allowlist is in `lib/contact.mjs`. The current hosting audience remains owner-private; public visitors require an explicit audience change through Sites. Email/WhatsApp notifications are not configured.

Run `node tests/contact.test.mjs` to check database persistence, validation, idempotency, access control and failure handling. Build and publish using the Sites workflow. No credentials belong in source control.
