import { sqliteTable, text, integer, index } from 'drizzle-orm/sqlite-core';
export const enquiries = sqliteTable('enquiries', {
 id:text('id').primaryKey(), name:text('name').notNull(), phone:text('phone').notNull(), email:text('email').notNull(), interest:text('interest').notNull(), message:text('message').notNull(),
 status:text('status').notNull().default('New'), createdAt:integer('created_at').notNull(), sourceHash:text('source_hash').notNull(), consent:integer('consent').notNull()
}, table => [index('enquiries_created').on(table.createdAt), index('enquiries_source').on(table.sourceHash,table.createdAt)]);
