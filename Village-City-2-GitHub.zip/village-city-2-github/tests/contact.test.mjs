import assert from 'node:assert/strict';
import { DatabaseSync } from 'node:sqlite';
import {readFileSync} from 'node:fs';
import {submit,list,update} from '../lib/contact.mjs';
const sqlite=new DatabaseSync(':memory:');sqlite.exec(readFileSync('drizzle/0000_fine_havok.sql','utf8'));
const db={
 prepare(sql){
  const statement=(args=[])=>({
   async first(){return sqlite.prepare(sql).get(...args)||null},
   async all(){return {results:sqlite.prepare(sql).all(...args)}},
   async run(){return {meta:{changes:Number(sqlite.prepare(sql).run(...args).changes)}}}
  });
  return {...statement(),bind(...args){return statement(args)}};
 }
};
const base={id:crypto.randomUUID(),name:'Test visitor',phone:'+91 98765 43210',email:'visitor@example.com',interest:'Arrange a site visit',message:'Saturday afternoon',consent:true};
function request(data,headers={},method='POST'){return new Request('https://example.test/api/enquiries',{method,headers:{origin:'https://example.test','content-type':'application/json','cf-connecting-ip':'192.0.2.1',...headers},...(method==='GET'?{}:{body:JSON.stringify(data)})})}
assert.equal((await submit(request({...base,consent:false}),db)).status,400);
assert.equal((await submit(request({...base,phone:'abc'}),db)).status,400);
assert.equal((await submit(request(base,{origin:'https://wrong.test'}),db)).status,403);
assert.equal((await submit(request(base),db)).status,201);
assert.equal((await submit(request(base),db)).status,200);
assert.equal(sqlite.prepare('SELECT COUNT(*) AS n FROM enquiries').get().n,1);
assert.equal(sqlite.prepare('SELECT name, message FROM enquiries').get().message,base.message);
assert.equal((await list(request(null,{},'GET'),db)).status,403);
const owner={'oai-authenticated-user-id':'test-owner','oai-authenticated-user-email':'shivamvijaypatel@gmail.com'};
assert.equal((await list(request(null,owner,'GET'),db)).status,200);
assert.equal((await update(request({id:base.id,status:'Contacted'},owner,'PATCH'),db)).status,200);
assert.equal(sqlite.prepare('SELECT status FROM enquiries').get().status,'Contacted');
assert.equal((await update(request({id:base.id,status:'Closed'},{},'PATCH'),db)).status,403);
assert.equal((await update(request({id:base.id,status:'invalid'},owner,'PATCH'),db)).status,400);
for(let i=0;i<4;i++)assert.equal((await submit(request({...base,id:crypto.randomUUID()}),db)).status,201);
assert.equal((await submit(request({...base,id:crypto.randomUUID()}),db)).status,429);
assert.equal((await submit(request({...base,id:crypto.randomUUID()},{'cf-connecting-ip':'192.0.2.2'}),{prepare(){throw Error('unavailable')}})).status,503);
for(const file of ['app/site.html','app/enquiries/inbox.html']){const html=readFileSync(file,'utf8');for(const match of html.matchAll(/<script>([\s\S]*?)<\/script>/g))new Function(match[1]);}
console.log('PASS: persistence, idempotency, validation, origin checks, owner authorization, status updates, rate limit, database failure and browser script syntax.');
