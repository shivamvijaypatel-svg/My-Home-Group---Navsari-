CREATE TABLE `enquiries` (
	`id` text PRIMARY KEY NOT NULL,
	`name` text NOT NULL,
	`phone` text NOT NULL,
	`email` text NOT NULL,
	`interest` text NOT NULL,
	`message` text NOT NULL,
	`status` text DEFAULT 'New' NOT NULL,
	`created_at` integer NOT NULL,
	`source_hash` text NOT NULL,
	`consent` integer NOT NULL
);
--> statement-breakpoint
CREATE INDEX `enquiries_created` ON `enquiries` (`created_at`);--> statement-breakpoint
CREATE INDEX `enquiries_source` ON `enquiries` (`source_hash`,`created_at`);